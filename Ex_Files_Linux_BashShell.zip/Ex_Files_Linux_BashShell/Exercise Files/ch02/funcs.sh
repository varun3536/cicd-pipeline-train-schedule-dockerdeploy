#!/bin/bash
function f {
   exit 1
}
echo starting
f
echo after f

