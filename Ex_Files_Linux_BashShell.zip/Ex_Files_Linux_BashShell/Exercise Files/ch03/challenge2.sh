File=${TheFile:-/tmp/data.file}
echo File is $File TheFile is $TheFile

