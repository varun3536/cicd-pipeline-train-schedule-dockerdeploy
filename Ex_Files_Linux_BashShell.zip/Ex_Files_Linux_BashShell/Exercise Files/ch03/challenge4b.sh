#!/bin/bash
sed 's/^ *//;s/ .*$//;1d'

